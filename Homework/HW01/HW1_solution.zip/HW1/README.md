# Homework 1

# TODO: make sure to add anything they might need that wasn't covered in lectures
